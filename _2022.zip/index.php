<?php
header("Status: 301 Moved Permanently");
header("Location:Login/");
exit;
?>